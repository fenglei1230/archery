from django.apps import AppConfig


class SqlApi2Config(AppConfig):
    name = 'sql_api'
